package com.ebay.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ebay.base.CommonPage;

public class DressesPage extends CommonPage{

	@FindBy(id="w_1504721177697_cbx")
	WebElement size;
	
	@FindBy(css="#w8-w0-w1_btn")
	WebElement bestMatchIcon;
	
	@FindBy(linkText="Newly Listed")
	WebElement bestMatchSelectValue;

	@FindBy(css=".s-item__title")
	List<WebElement> itemTitles;
	
	public DressesPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver,this);
	}
	
	public void selectSize () {
		size.click();
		
	}
	public List<WebElement> bestMatchSelect() {
		bestMatchIcon.click();
		bestMatchSelectValue.click();
		return itemTitles;
		
	}
	
	

}
