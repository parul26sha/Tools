package com.ebay.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ebay.base.CommonPage;

public class HomePage extends CommonPage {

	@FindBy(css=".hl-image.js-only.hl-item__bg-image>img")
	List<WebElement> dailyDealsList;
	
	@FindBy(css="#gh-shop-a")
	WebElement shopBycategory;
	
	@FindBy(xpath=".//*[@id='gh-sbc']/tbody/tr/td[2]/h3[1]/a\n")
	WebElement fashionIcon;
	
	@FindBy(css="..nav-wrapper")
	List<WebElement> h2Title;
	
	public HomePage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver,this);
	}
	
	public int counntH2title() {
		return h2Title.size();
	}
	
	public int dailyDeals() {
		return dailyDealsList.size();
	}
	
	public  FashionPage shopByCategory() {
		
		shopBycategory.click();
		fashionIcon.click();
		return new FashionPage(driver);
	}

}
