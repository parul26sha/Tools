package com.ebay.utility;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebdriverUtil {
	public static WebDriver getDriver(String driverName) {
		WebDriver driver=null;
		try {
			System.out.println("------->>>>");
			switch(driverName) {
				
				case "chrome":
					System.setProperty("webdriver.chrome.driver","/home/parul/Downloads/chromedriver.exe");
				    driver=new ChromeDriver();
				    break;
				case "firefox":
					System.setProperty("webdriver.gecko.driver","/home/parul/Downloads/geckodriver");
					driver=new FirefoxDriver();
					break;
				
				case "ie":
					//System.setProperty("webdriver.ie.driver","/home/parul/Desktop/Tools/AutomationFrameWork/resources/drivers/geckodriver");
					break;
				case "safari":
					//safari driver
					break;
			}
		
		}
		catch(Exception e){
			System.out.println("Exception wile creating a webdriver object");
			System.out.println(e.getStackTrace());	
		}
		
		return driver;
	}

}