package com.ebay.base;

public interface Constant {
	
	public String PATH=System.getProperty("user.dir")+"/resources/";
}
