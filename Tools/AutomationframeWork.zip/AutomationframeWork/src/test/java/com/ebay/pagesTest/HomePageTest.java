package com.ebay.pagesTest;

import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;

import java.awt.AWTException;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.ebay.base.BaseTest;
import com.ebay.pages.HomePage;

public class HomePageTest extends BaseTest {
	
	HomePage hm;
	
	@Test
	public void toplistTest() {
		hm=new HomePage(driver);
		assertEquals(hm.toplist(),5);
		assertEquals(hm.logoDisplayed(),true);
	}
	
	@Test
	public void search() throws AWTException {
		hm=new HomePage(driver);
		assertEquals(hm.search("apple watch"),"apple watch | eBay");
	
	}

}
