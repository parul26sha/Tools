package com.ebay.pagesTest;

import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.ebay.base.BaseTest;
import com.ebay.pages.DressesPage;
import com.ebay.pages.FashionPage;
import com.ebay.pages.HomePage;

public class DressPageTest extends BaseTest{
	
	HomePage hm;
	FashionPage fp;
	DressesPage dp;
		
	@Test
	public void printBestMatchList() {
		hm=new HomePage(driver);
		fp=hm.shopByCategory();
		dp=fp.womenSClothing();
		//assertEquals(dp.logoDisplayed(),true);
		List<WebElement> bestMatchElements=dp.bestMatchSelect();
		for(WebElement e:bestMatchElements) {
			System.out.println("title::"+e.getText());
		}
		assertEquals(dp.logoDisplayed(),true);
		
	
	}


}
